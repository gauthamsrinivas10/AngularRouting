// import { Component, OnDestroy, OnInit } from '@angular/core';
// import { response } from 'express';
// import { listenerCount } from 'process';
// import IEmployee from 'src/app/interface/employee2';
// import { EmpServiceService } from 'src/app/services/emp-service.service';
// import { Employee } from '../../model/Employee';
// @Component({
//   selector: 'employee-content',
//   templateUrl: './employee.component.html',
//   styleUrls: ['./employee.component.css']
// })
// export class EmployeeComponent implements OnInit, OnDestroy{

//   isErrorFetching : boolean = false;
  
// employeeList : IEmployee[] = [];
//   constructor( private list: EmpServiceService) { 
//    this.employeeList = list.employeeList;
//   }

  
// //   ngOnInit(): void {
// //     this.list.getService().subscribe({
// //       next : (data)=>{
// //       this.employeeList = data;
// //     },
// //     complete : ()=> {console.log("complete")},
// //     error : ()=>  {
// //       console.log("Error data")
// //       this.isErrorFetching = true;

// //     }
// //   })
// // }

// employees = new Array<Employee>();

// ngOnInit(): void {
//   this.list.getEmployees().subscribe( response =>
//     {
//       this.employees = response.map(item =>
// { 
//   return new Employee(
//     item.id,
//     item.employee_name,
//     item.employee_salary,
//     item.employee_age,
//     item.profile_image
//     );
//   });
// });
// }
//   ngOnDestroy() : void {

//   }

// }

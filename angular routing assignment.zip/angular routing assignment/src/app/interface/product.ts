export default interface IProduct {
    "id": number
    "product_name": string
    "price": number   
    "description": string
    "profile_image" : string
}